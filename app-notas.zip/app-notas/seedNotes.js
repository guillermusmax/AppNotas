// Cargar los datos de prueba en la base de datos
